# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

# Modèle représentant un consommable du parc informatique
class GestionParcConsumable(models.Model):
    _name = "gestionparcbk.stock.consumable"
    _description = "Consommable du parc"
    _inherit = ["mail.thread", "mail.activity.mixin"]  # Pour le suivi et les activités planifiées

    # Nom du consommable (visible dans les vues)
    name = fields.Char("Nom", required=True)

    # Produit Odoo associé (doit être de type consommable)
    product_id = fields.Many2one(
        "product.product",
        "Article (produit Odoo)",
        domain=[("type", "=", "consu")],
        required=True
    )

    # Unité de mesure (liée automatiquement à celle du produit)
    uom_id = fields.Many2one("uom.uom", related="product_id.uom_id", store=True, readonly=True)

    # Emplacement de stock par défaut (stock principal)
    location_id = fields.Many2one(
        "stock.location",
        "Emplacement",
        default=lambda s: s.env.ref("stock.stock_location_stock").id
    )

    # Quantité disponible automatiquement calculée
    quantity_on_hand = fields.Float("Quantité", compute="_compute_quantity", store=True)

    # Seuil minimum d’alerte
    threshold = fields.Float("Seuil minimum", default=0.0)

    # Quantité à recommander automatiquement en cas de seuil dépassé
    reorder_qty = fields.Float("Qté à commander", default=0.0)

    # Parc informatique auquel est lié le consommable
    parc_id = fields.Many2one("gestionparcbk.parc", "Parc affecté")

    # Réceptions liées à ce consommable
    receipt_ids = fields.One2many("gestionparcbk.stock.receipt", "consumable_id")

    # Société courante
    company_id = fields.Many2one("res.company", default=lambda s: s.env.company, readonly=True)

    # Contrainte d’unicité : un même produit ne peut être affecté qu’une seule fois à un parc
    _sql_constraints = [
        ("uniq_parc_product", "unique(parc_id, product_id)", "Ce consommable est déjà affecté à ce parc."),
    ]

    @api.depends("product_id", "location_id")
    def _compute_quantity(self):
        """
        Calcule la quantité en stock du produit pour l’emplacement donné.
        """
        Quant = self.env["stock.quant"]
        for rec in self:
            quant = Quant.search([
                ("product_id", "=", rec.product_id.id),
                ("location_id", "=", rec.location_id.id),
            ], limit=1)
            rec.quantity_on_hand = quant.quantity if quant else 0.0

    @api.onchange("product_id")
    def _onchange_product_id(self):
        """
        Met automatiquement à jour le champ 'name' selon le nom du produit sélectionné.
        """
        for rec in self:
            if rec.product_id:
                rec.name = rec.product_id.display_name

    def action_reorder(self):
        """
        Crée un bon de commande pour le produit si la quantité à commander est renseignée.
        """
        self.ensure_one()
        if self.reorder_qty <= 0:
            raise UserError(_("La quantité à commander doit être > 0."))

        # Recherche d’un fournisseur actif
        partner = self.env["res.partner"].search([("supplier_rank", ">", 0)], limit=1)
        if not partner:
            raise UserError(_("Aucun fournisseur n’est configuré !"))

        # Création du bon de commande
        po = self.env["purchase.order"].create({
            "partner_id": partner.id,
            "order_line": [(0, 0, {
                "product_id": self.product_id.id,
                "product_qty": self.reorder_qty,
                "price_unit": self.product_id.standard_price,
            })],
        })

        # Log de l'opération dans le chatter
        self.message_post(body=_("Bon de commande <b>%s</b> créé (%s unités).") % (po.name, self.reorder_qty))

        # Redirection vers le bon de commande créé
        return {
            "type": "ir.actions.act_window",
            "res_model": "purchase.order",
            "view_mode": "form",
            "res_id": po.id,
        }

    def _cron_check_threshold_alerts(self):
        """
        Méthode appelée automatiquement par le CRON pour détecter
        les consommables dont la quantité est en dessous du seuil défini.
        """
        Consumable = self.env['gestionparcbk.stock.consumable']
        alertables = Consumable.search([('quantity_on_hand', '<', 'threshold')])

        # Chargement du template d’email de notification
        template = self.env.ref("gestionparcbk.email_template_consumable_threshold")

        for consumable in alertables:
            if template:
                # Envoi d’un mail d’alerte automatique
                template.send_mail(consumable.id, force_send=True)
