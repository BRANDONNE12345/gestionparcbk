# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


# ------------------------------------------------------------
#  Sites d’un client (modèle conservé uniquement si utilisé)
# ------------------------------------------------------------
class ClientSite(models.Model):
    _name = "gestionparcbk.client.site"
    _description = "Site (adresse) d’un client"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char("Nom du site", required=True, tracking=True)
    partner_id = fields.Many2one(
        "res.partner", string="Client",
        domain="[('is_company', '=', True)]",
        required=True, ondelete="cascade")
    street      = fields.Char()
    city        = fields.Char()
    state_id    = fields.Many2one("res.country.state", string="État / région")
    zip         = fields.Char()
    country_id  = fields.Many2one("res.country", string="Pays")

    parc_ids   = fields.One2many("gestionparcbk.parc", "site_id", string="Parcs")
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company, readonly=True)


# ------------------------------------------------------------
#  Parc informatique (client + site)
# ------------------------------------------------------------
class GestionParc(models.Model):
    _name = "gestionparcbk.parc"
    _description = "Parc informatique"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "partner_id, site_id"

    # --- Identification ---------------------------------------------------
    name = fields.Char("Référence parc", required=True, tracking=True)
    partner_id = fields.Many2one(
        "res.partner", string="Client",
        domain="[('is_company', '=', True)]",
        required=True, tracking=True)
    site_id = fields.Many2one(
        "gestionparcbk.client.site", string="Site",
        domain="[('partner_id', '=', partner_id)]",
        required=True, tracking=True)

    # - SUPPRIMÉ : les many2many redondants (à la place on utilisera One2many inversé via parc_id)
    # materiel_ids = ...
    # logiciel_ids = ...
    # consumable_ids = ...

    # + NOUVEAU : liens inverses via One2many — plus propre
    materiel_ids = fields.One2many(
        "gestionparcbk.stock.materiel", "parc_id", string="Matériels affectés")

    logiciel_ids = fields.One2many(
        "gestionparcbk.stock.logiciel", "parc_id", string="Logiciels installés")

    consumable_ids = fields.One2many(
        "gestionparcbk.stock.consumable", "parc_id", string="Consommables suivis")

    # --- Compteurs --------------------------------------------------------
    materiel_count   = fields.Integer(
        string="Matériels", compute="_compute_counts", store=False)
    logiciel_count   = fields.Integer(
        string="Logiciels", compute="_compute_counts", store=False)
    consumable_count = fields.Integer(
        string="Consommables", compute="_compute_counts", store=False)

    # + CHAMP SOCIÉTÉ (bonnes pratiques multi-company)
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company, readonly=True)

    # ======================================================================
    #  COMPUTES
    # ======================================================================
    def _compute_counts(self):
        for rec in self:
            rec.materiel_count = len(rec.materiel_ids)
            rec.logiciel_count = len(rec.logiciel_ids)
            rec.consumable_count = len(rec.consumable_ids)

    # ======================================================================
    #  LOGIQUE DÉSAFFECTATION AUTOMATIQUE SI LE PARC EST MODIFIÉ
    # ======================================================================
    def unlink(self):
        """Quand un parc est supprimé, on libère les équipements liés."""
        self.materiel_ids.write({'parc_id': False})
        self.logiciel_ids.write({'parc_id': False})
        self.consumable_ids.write({'parc_id': False})
        return super().unlink()

    def write(self, vals):
        """
        Si changement de site/partenaire ➜ logique future possible à implémenter ici.
        Pour l’instant, pas de synchronisation forcée avec objets liés.
        """
        return super().write(vals)

