# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

class SubscriptionPlan(models.Model):
    _name = 'gestionparcbk.subscription.plan'
    _description = "Plan d'abonnement"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name'

    name = fields.Char("Nom du plan", required=True, tracking=True)
    description = fields.Text("Description")
    recurrence_unit = fields.Selection([
        ('monthly', 'Mensuel'),
        ('quarterly', 'Trimestriel'),
        ('yearly', 'Annuel'),
    ], string="Périodicité", required=True, default='monthly', tracking=True)
    price = fields.Monetary("Prix unitaire", required=True)
    currency_id = fields.Many2one('res.currency', string="Devise", default=lambda self: self.env.company.currency_id)
    contract_ids = fields.One2many('gestionparcbk.service.contract', 'subscription_plan_id', string="Contrats liés")


class AccountMove(models.Model):
    _inherit = 'account.move'

    contract_id = fields.Many2one('gestionparcbk.service.contract', string="Contrat lié", ondelete="set null")
