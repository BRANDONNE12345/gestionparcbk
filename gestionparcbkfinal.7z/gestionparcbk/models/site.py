# -*- coding: utf-8 -*-
from odoo import fields, models

class GestionParcSite(models.Model):
    _name = 'gestionparcbk.site'
    _description = 'Site client'
    _inherit = ['mail.thread', 'mail.activity.mixin']   #  <-- ajouté
    _order = 'name'

    name       = fields.Char('Nom du site', required=True, tracking=True)
    partner_id = fields.Many2one('res.partner', 'Client', required=True)
    address_id = fields.Many2one(
        'res.partner', 'Adresse',
        domain="[('parent_id','=',partner_id)]")
    parc_ids   = fields.One2many('gestionparcbk.parc', 'site_id', string='Parcs')
    company_id = fields.Many2one(
        'res.company', default=lambda self: self.env.company, readonly=True)
