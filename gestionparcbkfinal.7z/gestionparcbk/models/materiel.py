# -*- coding: utf-8 -*-
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class GestionParcMateriel(models.Model):
    _name = "gestionparcbk.stock.materiel"
    _description = "Matériel du parc informatique"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "purchase_date desc"

    # + CHAMP LIÉ AU PARC ➜ One2many depuis parc
    parc_id = fields.Many2one("gestionparcbk.parc", string="Parc affecté", index=True, tracking=True)

    # + CHAMP CLIENT dérivé du parc
    partner_id = fields.Many2one(
        'res.partner', string="Client",
        related='parc_id.partner_id',
        store=True, readonly=True)

    name = fields.Char("N° de série / Référence", required=True, tracking=True)
    type = fields.Selection([
        ("ordinateur", "Ordinateur"),
        ("imprimante", "Imprimante"),
        ("routeur", "Routeur"),
        ("camera", "Caméra"),
        ("autre", "Autre"),
    ], required=True, tracking=True)

    marque = fields.Char("Marque")
    modele = fields.Char("Modèle")

    purchase_date = fields.Date("Date d’achat")
    warranty_months = fields.Integer("Durée de garantie (mois)", default=12)
    warranty_end = fields.Date("Fin de garantie", compute="_compute_warranty_end", store=True)
    is_warranty_expired = fields.Boolean("Garantie expirée", compute="_compute_warranty_end", store=True)

    # + ÉTAT AUTOMATIQUE
    state = fields.Selection([
        ("available", "Disponible"),
        ("assigned", "Assigné"),
        ("maintenance", "En maintenance"),
        ("scrapped", "Hors service"),
    ], default="available", tracking=True)

    user_id = fields.Many2one("res.users", "Utilisateur assigné")
    location_id = fields.Many2one(
        "stock.location", "Emplacement actuel",
        default=lambda self: self.env.ref("stock.stock_location_stock").id)

    notes = fields.Html("Notes")
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, readonly=True)

    # ------------------------------------------
    # COMPUTE : garantie et expiration
    # ------------------------------------------
    @api.depends("purchase_date", "warranty_months")
    def _compute_warranty_end(self):
        today = fields.Date.context_today(self)
        for rec in self:
            rec.warranty_end = (
                rec.purchase_date + relativedelta(months=rec.warranty_months)
                if rec.purchase_date and rec.warranty_months else False
            )
            rec.is_warranty_expired = bool(rec.warranty_end and rec.warranty_end < today)

    # ------------------------------------------
    # SYNC STATE AUTOMATIQUE
    # ------------------------------------------
    @api.onchange("parc_id")
    def _onchange_parc_id(self):
        for rec in self:
            rec.state = "assigned" if rec.parc_id else "available"

    def write(self, vals):
        res = super().write(vals)
        if "parc_id" in vals:
            for rec in self:
                rec.state = "assigned" if rec.parc_id else "available"
        return res

    # ------------------------------------------
    # BOUTONS DE CHANGEMENT DE STATUT
    # ------------------------------------------
    def action_set_state(self, new_state):
        selection = dict(self._fields["state"].selection)
        if new_state not in selection:
            raise ValidationError(_("État invalide : %s") % new_state)
        for rec in self:
            rec.state = new_state
            rec.message_post(body=_("État changé à <b>%s</b>.") % selection[new_state])
        return True

    def action_available(self): return self.action_set_state("available")
    def action_assign(self): return self.action_set_state("assigned")
    def action_maintenance(self): return self.action_set_state("maintenance")
    def action_scrap(self): return self.action_set_state("scrapped")
