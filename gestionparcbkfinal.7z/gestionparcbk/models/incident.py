# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime

class GestionParcIncident(models.Model):
    _inherit = 'helpdesk.ticket'
    _description = "Ticket d'incident étendu pour le parc informatique"

    equipment_id = fields.Many2one(
        'gestionparcbk.stock.materiel', string="Équipement concerné",
        help="Matériel ou périphérique lié à cet incident")
    intervention_ids = fields.One2many(
    'gestionparcbk.intervention', 'ticket_id', string="Interventions")

    priority = fields.Selection([
        ('0', 'Critique'),
        ('1', 'Élevée'),
        ('2', 'Normale'),
        ('3', 'Basse'),
    ], default='2', string="Priorité", tracking=True)
    technician_id = fields.Many2one(
        'res.users', string="Technicien assigné",
        help="Utilisateur responsable du traitement de ce ticket")
    sla_deadline = fields.Datetime(
        string="Date limite SLA",
        compute='_compute_sla_deadline', store=True,
        help="Date/heure limite selon le SLA")

    @api.depends('create_date', 'priority')
    def _compute_sla_deadline(self):
        # Durées SLA en heures selon la priorité
        hours_map = {
            '0': 4,    # Critique
            '1': 8,    # Élevée
            '2': 24,   # Normale
            '3': 48,   # Basse
        }
        for rec in self:
            # Tant que le ticket n'est pas sauvegardé, pas de create_date → pas de SLA
            if not rec.create_date:
                rec.sla_deadline = False
            else:
                delta = hours_map.get(rec.priority, 24)
                rec.sla_deadline = rec.create_date + relativedelta(hours=delta)
    
    def _cron_check_sla(self):
        now = fields.Datetime.now()
        overdue_tickets = self.search([
            ('sla_deadline', '<', now),
            ('stage_id.name', '!=', 'Terminé'),
        ])
        for ticket in overdue_tickets:
            ticket.message_post(
                body=_("⏰ SLA dépassé pour ce ticket."),
                subtype_xmlid="mail.mt_note"
            )  
        template = self.env.ref('gestionparcbk.email_template_sla_alert', raise_if_not_found=False)
        if template:
            template.send_mail(ticket.id, force_send=True)

