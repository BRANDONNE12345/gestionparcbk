# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class GestionParcLogiciel(models.Model):
    _name = "gestionparcbk.stock.logiciel"
    _description = "Logiciel installé sur le parc"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name, version"

    name = fields.Char("Nom", required=True)
    version = fields.Char("Version", required=True)
    vendor = fields.Char("Éditeur", required=True)
    vendor_url = fields.Char("Site éditeur")

    installation_date = fields.Date("Date d'installation", default=fields.Date.context_today)
    support_end_date = fields.Date("Fin du support")
    is_expired = fields.Boolean("Support expiré", compute="_compute_is_expired", store=True)

    # + RELATION PARC
    parc_id = fields.Many2one("gestionparcbk.parc", "Parc installé")
    user_id = fields.Many2one("res.users", "Utilisateur assigné")
    notes = fields.Text("Notes")

    company_id = fields.Many2one("res.company", default=lambda s: s.env.company, readonly=True)

    # ✱ MODIFICATION AUTOMATIQUE DE L'ÉTAT
    state = fields.Selection([
        ("installed", "Installé"),
        ("archived", "Archivé"),
    ], default="installed", tracking=True, required=True)

    licence_ids = fields.One2many("gestionparcbk.stock.licence", "logiciel_id", "Licences")
    license_count = fields.Integer("Nb licences", compute="_compute_license_count", store=True)

    _sql_constraints = [
        ("name_version_uniq", "unique(name,version)", "Le même logiciel (même version) existe déjà !"),
    ]

    @api.depends("support_end_date")
    def _compute_is_expired(self):
        today = fields.Date.context_today(self)
        for rec in self:
            rec.is_expired = bool(rec.support_end_date and rec.support_end_date < today)

    @api.depends("licence_ids")
    def _compute_license_count(self):
        for rec in self:
            rec.license_count = len(rec.licence_ids)

    @api.onchange("parc_id")
    def _onchange_parc_id(self):
        for rec in self:
            rec.state = "installed" if rec.parc_id else "archived"

    def write(self, vals):
        res = super().write(vals)
        if "parc_id" in vals:
            for rec in self:
                rec.state = "installed" if rec.parc_id else "archived"
        return res

    def action_archive(self):
        self.write({"state": "archived"})
        self.message_post(body=_("Logiciel archivé."))

    def action_restore(self):
        self.write({"state": "installed"})
        self.message_post(body=_("Logiciel restauré."))

    def action_view_expired(self):
        return {
            "name": _("Logiciels expirés"),
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "view_mode": "list,form",
            "domain": [("support_end_date", "<", fields.Date.context_today(self))],
        }


class GestionParcLicence(models.Model):
    _name = "gestionparcbk.stock.licence"
    _description = "Licence logicielle"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "expiration_date"

    logiciel_id = fields.Many2one("gestionparcbk.stock.logiciel", "Logiciel", required=True, ondelete="cascade")
    name = fields.Char("Libellé", required=True)
    license_key = fields.Char("Clé", required=True)
    license_count = fields.Integer("Quantité", default=1)
    expiration_date = fields.Date("Expiration", required=True)

    is_expired = fields.Boolean("Expirée", compute="_compute_is_expired", store=True)
    state = fields.Selection([("valid", "Valide"), ("expired", "Expirée")], compute="_compute_state", store=True)
    is_renewed = fields.Boolean("Renouvelée", default=False)  # + nouveau champ

    company_id = fields.Many2one("res.company", default=lambda s: s.env.company, readonly=True)

    @api.depends("expiration_date")
    def _compute_is_expired(self):
        today = fields.Date.context_today(self)
        for rec in self:
            rec.is_expired = bool(rec.expiration_date and rec.expiration_date < today)

    @api.depends("is_expired")
    def _compute_state(self):
        for rec in self:
            rec.state = "expired" if rec.is_expired and not rec.is_renewed else "valid"