from odoo import models, fields, api

class GestionParcReceipt(models.Model):
    _name = 'gestionparcbk.stock.receipt'
    _description = 'Historique des réceptions de consommables'

    consumable_id = fields.Many2one(
        'gestionparcbk.stock.consumable',
        string='Consommable', required=True, ondelete='cascade')
    purchase_id = fields.Many2one(
        'purchase.order', string='Bon de commande', required=True)
    date = fields.Datetime(
        string='Date de réception', default=fields.Datetime.now,
        required=True)
    quantity = fields.Float(string='Quantité reçue', required=True)
    name = fields.Char(
        string='Description', compute='_compute_name', store=True)

    @api.depends('purchase_id', 'quantity')
    def _compute_name(self):
        for rec in self:
            rec.name = "%s – %s" % (
                rec.purchase_id.name or '', rec.quantity)
