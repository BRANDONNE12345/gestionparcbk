# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError

# ===============================
# Modèle principal : Contrat de service
# ===============================
class GestionParcServiceContract(models.Model):
    _name = 'gestionparcbk.service.contract'
    _description = 'Contrat de service'
    _inherit = ['mail.thread', 'mail.activity.mixin']  # Suivi et planification
    _order = 'date_start desc'  # Tri par date de début descendante

    # Informations de base du contrat
    name = fields.Char('Numéro de contrat', required=True, tracking=True)
    partner_id = fields.Many2one(
        'res.partner', 'Client',
        domain=[('is_company', '=', True)],
        required=True, tracking=True
    )
    responsible_id = fields.Many2one(
        'res.users', string="Responsable",
        default=lambda self: self.env.user
    )

    # Type de contrat (obligatoire)
    type = fields.Selection([
        ('maintenance', 'Maintenance'),
        ('support', 'Support'),
        ('licence', 'Licence'),
    ], string='Type de contrat', required=True, tracking=True)

    # Période du contrat
    date_start = fields.Date('Date de début', default=fields.Date.context_today, required=True, tracking=True)
    date_end = fields.Date('Date de fin', required=True, tracking=True)

    # Fréquence de renouvellement du contrat
    recurrence_unit = fields.Selection([
        ('monthly', 'Mensuel'),
        ('quarterly', 'Trimestriel'),
        ('yearly', 'Annuel'),
    ], string='Périodicité', required=True, default='yearly', tracking=True)

    # Indique si le contrat est renouvelé automatiquement
    renewal_auto = fields.Boolean('Renouvellement auto.', default=True, tracking=True)
    renewal_count = fields.Integer("Renouvellements", default=0)

    # Référence vers le plan d’abonnement défini
    subscription_plan_id = fields.Many2one('gestionparcbk.subscription.plan', string="Plan d’abonnement")

    # Équipements couverts par le contrat
    equipment_ids = fields.Many2many(
        'maintenance.equipment',
        'contract_equipment_rel', 'contract_id', 'equipment_id',
        string="Équipements couverts"
    )

    # Description des services inclus
    service_lines = fields.Text('Prestations incluses')

    # Montant total du contrat
    amount_total = fields.Monetary("Montant", currency_field="currency_id")
    currency_id = fields.Many2one('res.currency', string="Devise", default=lambda self: self.env.company.currency_id)

    # Notes diverses
    note = fields.Text("Notes")

    # Liste des factures associées
    invoice_ids = fields.One2many('account.move', 'contract_id', string="Factures générées")
    invoice_count = fields.Integer(string="Nb Factures", compute="_compute_invoice_count")

    # Statut du contrat : géré dynamiquement selon les dates
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('active', 'Actif'),
        ('expired', 'Expiré'),
        ('cancelled', 'Annulé'),
    ], string='Statut', default='draft', tracking=True, compute='_compute_state', store=True)

    # ==============================================
    # Méthodes de calculs
    # ==============================================

    @api.depends('invoice_ids')
    def _compute_invoice_count(self):
        """Calcule automatiquement le nombre de factures liées au contrat"""
        for contract in self:
            contract.invoice_count = len(contract.invoice_ids)

    @api.depends('date_start', 'date_end')
    def _compute_state(self):
        """Détermine le statut du contrat (actif, expiré, etc.) en fonction des dates"""
        today = fields.Date.context_today(self)
        for rec in self:
            if rec.state == 'cancelled':
                continue
            if rec.date_start <= today <= rec.date_end:
                rec.state = 'active'
            elif rec.date_end < today:
                rec.state = 'expired'
            else:
                rec.state = 'draft'

    # ==============================================
    # Actions manuelles
    # ==============================================

    def action_cancel(self):
        """Annule manuellement un contrat"""
        for rec in self:
            rec.state = 'cancelled'

    def action_set_active(self):
        """Réactive un contrat annulé si les dates sont valides"""
        today = fields.Date.context_today(self)
        for rec in self:
            if rec.state == 'cancelled':
                if rec.date_start <= today <= rec.date_end:
                    rec.state = 'active'
                elif rec.date_end < today:
                    rec.state = 'expired'
                else:
                    rec.state = 'draft'

    def action_renew(self):
        """Renouvelle automatiquement le contrat selon sa périodicité"""
        for rec in self:
            if not rec.renewal_auto:
                raise ValidationError(_("Renouvellement automatique désactivé."))
            # Durée à ajouter selon la périodicité
            delta = {
                'monthly': relativedelta(months=1),
                'quarterly': relativedelta(months=3),
                'yearly': relativedelta(years=1)
            }.get(rec.recurrence_unit, relativedelta(years=1))
            # Mise à jour des dates et du compteur
            rec.write({
                'date_start': rec.date_end,
                'date_end': rec.date_end + delta,
                'renewal_count': rec.renewal_count + 1
            })
            rec.message_post(body=_("Contrat renouvelé jusqu'au %s") % rec.date_end)

    def action_generate_invoice(self):
        """Génère manuellement une facture pour le contrat"""
        self.ensure_one()
        if not self.subscription_plan_id:
            raise ValidationError(_("Aucun plan d'abonnement n’est défini."))

        # Recherche d'un compte de revenus
        income_account = self.env['account.account'].search([
            ('internal_type', '=', 'income'),
            ('deprecated', '=', False)
        ], limit=1)

        if not income_account:
            raise ValidationError(_("Aucun compte de revenus n’est défini."))

        # Création de la facture
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'invoice_date': fields.Date.context_today(self),
            'invoice_origin': self.name,
            'contract_id': self.id,
            'invoice_line_ids': [(0, 0, {
                'name': self.subscription_plan_id.name,
                'price_unit': self.subscription_plan_id.price,
                'quantity': 1,
                'currency_id': self.currency_id.id,
                'account_id': income_account.id,
            })],
        })
        invoice.action_post()
        self.message_post(body=_("Facture générée manuellement : <b>%s</b>") % invoice.name)

        # Redirection vers la facture générée
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'form',
            'res_id': invoice.id,
        }

    def action_view_invoices(self):
        """Affiche toutes les factures liées à ce contrat"""
        return {
            'name': _("Factures du contrat"),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [('contract_id', '=', self.id)],
            'context': {'default_contract_id': self.id},
        }

# ===============================
# Extension du modèle client (res.partner)
# ===============================
class Partner(models.Model):
    _inherit = 'res.partner'

    # Liste des contrats associés au client
    contract_ids = fields.One2many('gestionparcbk.service.contract', 'partner_id', string="Contrats")
    contract_count = fields.Integer(string="Nb contrats", compute='_compute_contract_count')

    def _compute_contract_count(self):
        """Calcule le nombre total de contrats liés au client"""
        for partner in self:
            partner.contract_count = len(partner.contract_ids)

    def action_view_contracts(self):
        """Action bouton pour afficher les contrats du client dans la vue"""
        return {
            'name': _("Contrats de service"),
            'type': 'ir.actions.act_window',
            'res_model': 'gestionparcbk.service.contract',
            'view_mode': 'tree,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {'default_partner_id': self.id},
        }
