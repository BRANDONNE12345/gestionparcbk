# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class TicketPrestation(models.Model):
    _name = 'gestionparcbk.ticket.prestation'
    _description = "Demande de prestation (infogérance)"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'

    name = fields.Char(string="Objet", required=True, tracking=True)
    partner_id = fields.Many2one('res.partner', string="Client", tracking=True)
    email = fields.Char("Email")
    phone = fields.Char("Téléphone")
    description = fields.Text(string="Description de la demande", tracking=True)

    service_type = fields.Selection([
        ('maintenance', 'Maintenance'),
        ('support', 'Support technique'),
        ('logiciel', 'Déploiement logiciel'),
        ('materiel', 'Installation matérielle'),
        ('autre', 'Autre'),
    ], string="Type de service demandé", required=True)

    state = fields.Selection([
        ('draft', 'Nouveau'),
        ('in_progress', 'En traitement'),
        ('done', 'Traitée'),
        ('rejected', 'Rejetée')
    ], string="Statut", default='draft', tracking=True)

    def action_in_progress(self):
        for rec in self:
            rec.state = 'in_progress'

    def action_done(self):
        for rec in self:
            rec.state = 'done'

    def action_reject(self):
        for rec in self:
            rec.state = 'rejected'
