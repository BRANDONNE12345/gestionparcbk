from odoo import models, fields, api
from odoo.exceptions import UserError
class GestionParcIntervention(models.Model):
    _name = 'gestionparcbk.intervention'
    _description = "Intervention technique liée à un incident"

    ticket_id = fields.Many2one('helpdesk.ticket', string="Ticket associé", required=True, ondelete='cascade')
    technician_id = fields.Many2one('res.users', string="Technicien", required=True)
    start_date = fields.Datetime(string="Début d’intervention")
    end_date = fields.Datetime(string="Fin d’intervention")
    duration = fields.Float(string="Durée (h)", compute="_compute_duration", store=True)
    parts_used = fields.Text(string="Pièces ou consommables utilisés")
    notes = fields.Text(string="Rapport d’intervention")
    def action_mark_done(self):
        for rec in self:
            if rec.state not in ['planned', 'in_progress']:
                raise UserError("Vous ne pouvez clôturer qu'une intervention en cours ou prévue.")
            rec.state = 'done'


    state = fields.Selection([
        ('planned', 'Prévue'),
        ('in_progress', 'En cours'),
        ('done', 'Réalisée'),
        ('cancelled', 'Annulée'),
    ], string="État", default='planned')

    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for rec in self:
            if rec.start_date and rec.end_date:
                delta = rec.end_date - rec.start_date
                rec.duration = delta.total_seconds() / 3600
            else:
                rec.duration = 0.0
