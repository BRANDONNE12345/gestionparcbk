# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal

# Définition de la classe du portail client, héritée du portail standard d'Odoo
class GestionParcBKPortal(CustomerPortal):

    # Route publique accessible sans authentification
    @http.route(['/gestionparcbk'], type='http', auth='public', website=True)
    def portail_accueil(self, **kw):
        # Affiche la page d'accueil publique du portail
        return request.render('gestionparcbk.portail_accueil_template', {})

    # Route pour afficher les contrats liés à l'utilisateur connecté
    @http.route(['/my/contracts'], type='http', auth='user', website=True)
    def portal_my_contracts(self, **kw):
        # Récupération du partenaire lié à l'utilisateur connecté
        partner = request.env.user.partner_id
        # Recherche des contrats liés à ce partenaire
        contracts = request.env['gestionparcbk.service.contract'].search([
            ('partner_id', '=', partner.id)
        ])
        # Rendu du template avec les contrats récupérés
        return request.render('gestionparcbk.portal_my_contracts', {
            'contracts': contracts
        })

    # Route pour afficher les tickets de support de l'utilisateur connecté
    @http.route(['/my/tickets'], type='http', auth='user', website=True)
    def portal_my_tickets(self, **kw):
        partner = request.env.user.partner_id
        tickets = request.env['helpdesk.ticket'].search([
            ('partner_id', '=', partner.id)
        ])
        return request.render('gestionparcbk.portal_my_tickets', {
            'tickets': tickets
        })

    # Route pour afficher les équipements associés au partenaire connecté
    @http.route(['/my/equipements'], type='http', auth='user', website=True)
    def portal_my_equipements(self, **kw):
        partner = request.env.user.partner_id
        equipements = request.env['gestionparcbk.stock.materiel'].search([
            ('partner_id', '=', partner.id)
        ])
        return request.render('gestionparcbk.portal_my_equipements', {
            'equipements': equipements
        })

    # Route permettant à l'utilisateur de soumettre une demande de prestation
    @http.route(['/my/prestation/request'], type='http', auth='user', website=True, csrf=True)
    def portal_create_prestation(self, **kw):
        # Si la méthode HTTP est POST, on traite l'envoi du formulaire
        if http.request.httprequest.method == 'POST':
            partner = request.env.user.partner_id
            # Création du dictionnaire de valeurs à partir des champs envoyés
            values = {
                'name': kw.get('name'),
                'partner_id': partner.id,
                'email': partner.email or kw.get('email'),
                'phone': partner.phone or kw.get('phone'),
                'service_type': kw.get('service_type'),
                'description': kw.get('description'),
            }
            # Création d’un enregistrement de demande de prestation
            request.env['gestionparcbk.ticket.prestation'].sudo().create(values)
            # Affichage de la page de remerciement
            return request.render('gestionparcbk.portal_prestation_thankyou')

        # Si ce n’est pas un POST, on affiche simplement le formulaire
        return request.render('gestionparcbk.portal_prestation_form')

    # Surcharge de la méthode Odoo pour injecter des données dans le tableau de bord utilisateur
    def _prepare_portal_layout_values(self):
        """
        Ajoute les compteurs visibles dans le tableau de bord portail.
        """
        values = super()._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        # Ajout des compteurs : nombre de contrats, tickets et équipements
        values.update({
            'contract_count': request.env['gestionparcbk.service.contract']
                .search_count([('partner_id', '=', partner.id)]),
            'ticket_count': request.env['helpdesk.ticket']
                .search_count([('partner_id', '=', partner.id)]),
            'equipment_count': request.env['gestionparcbk.stock.materiel']
                .search_count([('partner_id', '=', partner.id)]),
        })
        return values
