# __manifest__.py  –  gestionparcbk
{
    "name": "Gestion Parc BK",
    "version": "2.0",                       # ↑ pense à incrémenter
    "summary": "Gestion complète de parc informatique (clients, sites, matériels, logiciels, consommables).",
    "description": """
Gestion des parcs clients : sites, matériels, licences, consommables.
Alertes seuils, assignation automatique, intégration inventaire Odoo.
""",
    "author": "Votre Societe",
    "category": "Services/IT",
    "license": "LGPL-3",

    # modules Odoo dont on a besoin
    "depends": [
        "base",
        "sale_subscription", 
        "mail",
        "product",
        "stock",        # stock.location, stock.quant
        "purchase",     # création automatique de purchase.order
        "helpdesk", 
        "maintenance",
        "account", 
        'website',
        'portal',
        'auth_signup'
         # pour les contrats
    ],

    # données chargées à l’installation / mise-à-jour
    "data": [
        # sécurité
        "security/ir.model.access.csv",

        # données techniques
        "data/email_template_threshold.xml",
        "data/cron_threshold_alert.xml",
        "data/helpdesk_data.xml",
        "data/cron_sla_alert.xml",
        "data/email_template_contract_renewal.xml",
        "data/cron_contract_renewal_alert.xml",
        "data/cron_subscription_invoice.xml",
        

        # vues (l’ordre n’a pas d’importance mais c’est plus lisible)
        "views/parc_views.xml",          # ← nouveau
        "views/consommable_views.xml",
        "views/receipt_views.xml",
        "views/logiciel_views.xml",
        "views/materiel_views.xml",
        "views/incident_views.xml",
        "views/intervention_views.xml",
        "views/contract_views.xml",
        "views/subscription_views.xml",
        "views/ticket_prestation_views.xml",
        'views/portal_templates.xml',
        



        "views/menu.xml",
    ],
    "images": ["static/description/logo.png"],

    "installable": True,
    "application": False                # passe à True si tu veux une appli sur le dashbord
    
}
